# LVK — site institucional

Site estático responsivo da LVK Soluções Elétricas & Automação.

## Arquivos
- index.html
- style.css
- assets/logo-lvk.png
- assets/capa-lvk.png
- assets/servicos-lvk.png

## Publicar gratuitamente no GitHub Pages
1. Crie uma conta no GitHub.
2. Crie um repositório público chamado `lvksolucoes.github.io` (ou outro nome).
3. Envie todos os arquivos desta pasta para o repositório.
4. Em Settings > Pages, escolha a publicação pela branch `main` e pela pasta `/root`.
5. Salve e aguarde a publicação.

O botão de WhatsApp já está configurado para (42) 98401-1222.
